i = imread('b18.jpg');
