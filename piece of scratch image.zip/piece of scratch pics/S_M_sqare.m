function [A_M_squar,D_M_squar] = S_M_sqare(multivariate_processing_unit)
%S_M_SQARE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[m,n] = size(multivariate_processing_unit);
% m and n must be even protect here
if mod(m,2)~=0
    m = m -1;
end

if mod(n,2)~=0
    n = n -1;
end

A_vector = [];
D_vector = [];
    
for i = 1 : (m/2)
    for j = 1: (n/2)
        % wavelet processing unit has 4*4 pixel
        wavelet_processing_unit = multivariate_processing_unit(2*i-1 :2*i, 2*j-1:2*j);
        [a,h,v,d] = haart2(wavelet_processing_unit,'integer');
        A_vector = [A_vector,a];
        % fomular 16
        d_value = 1/3 * h + 1/3 * v + 1/3 * d;
        D_vector = [D_vector,d_value];
    end
end
% Formular 17
A_M_squar = var(A_vector);
D_M_squar = mean(D_vector);
num = size(A_vector);
sum
for i = 1:num
   A_M_squar = (1/(m/2*n/2 - 1)) *
end

