load('g1_cov.mat');
load('g1_xbar.mat');
