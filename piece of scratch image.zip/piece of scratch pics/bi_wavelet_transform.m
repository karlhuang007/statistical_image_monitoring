function [cov] = bi_wavelet_transform(unit1,unit2,num1,num2)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[m,n] = size(unit1);
% m and n must be even protect here
if mod(m,2)~=0
    m = m -1;
end

if mod(n,2)~=0
    n = n -1;
end

vector1 = []
vector2 = [];
if mod(num1,2)~=0 && mod(num2,2)~=0
        % covariance of image1's A and image2's A
        for i = 1 : (m/2)
            for j = 1: (n/2)
                % wavelet processing unit has 4*4 pixel
                wavelet_processing_unit1 = unit1(2*i-1 :2*i, 2*j-1:2*j);
                [a1,h1,v1,d1] = haart2(wavelet_processing_unit1,'integer');
                vector1 = [vector1,a1];
                % fomula 16
                wavelet_processing_unit2 = unit2(2*i-1 :2*i, 2*j-1:2*j);
                [a2,h2,v2,d2] = haart2(wavelet_processing_unit2,'integer');
                vector2 = [vector2,a2];
            end
        end
        A1_mean = mean(vector1);
        A2_mean = mean(vector2);
        s = size(unit1);
        sum = 0;
        for k = 1:s
            sum = sum+(vector1(k)-A1_mean)*(vector2(k)-A2_mean);
        end
        cov = sum/(m*n-1);
elseif mod(num1,2)==0 && mod(num2,2)==0
        % covariance of image1's D and image2's D
        for i = 1 : (m/2)
            for j = 1: (n/2)
                % wavelet processing unit has 4*4 pixel
                wavelet_processing_unit1 = unit1(2*i-1 :2*i, 2*j-1:2*j);
                [a1,h1,v1,d1] = haart2(wavelet_processing_unit1,'integer');

                d_value1 = 1/3 * h1 + 1/3 * v1 + 1/3 * d1;

                vector1 = [vector1,d_value1];
                % fomula 16
                wavelet_processing_unit2 = unit2(2*i-1 :2*i, 2*j-1:2*j);
                [a2,h2,v2,d2] = haart2(wavelet_processing_unit2,'integer');
                d_value2 = 1/3 * h2 + 1/3 * v2 + 1/3 * d2;
                vector2 = [vector2,d_value2];
            end
        end
        A1_mean = mean(vector1);
        A2_mean = mean(vector2);
        s = size(unit1);
        sum = 0;
        for k = 1:s
            sum = sum+(vector1(k)-A1_mean)*(vector2(k)-A2_mean);
        end
        cov = sum/(m*n-1);
else
    if mod(num1,2)~=0 && mod(num2,2)==0
        % iamge1'A and image2' D
        for i = 1 : (m/2)
            for j = 1: (n/2)
                % wavelet processing unit has 4*4 pixel
                wavelet_processing_unit1 = unit1(2*i-1 :2*i, 2*j-1:2*j);
                [a1,h1,v1,d1] = haart2(wavelet_processing_unit1,'integer');
                vector1 = [vector1,a1];
                % fomula 16
                wavelet_processing_unit2 = unit2(2*i-1 :2*i, 2*j-1:2*j);
                [a2,h2,v2,d2] = haart2(wavelet_processing_unit2,'integer');
                d_value2 = 1/3 * h2 + 1/3 * v2 + 1/3 * d2;
                vector2 = [vector2,d_value2];
            end
        end
        A1_mean = mean(vector1);
        A2_mean = mean(vector2);
        s = size(unit1);
        sum = 0;
        for k = 1:s
            sum = sum+(vector1(k)-A1_mean)*(vector2(k)-A2_mean);
        end
        cov = sum/(m*n-1);
    else
        % % iamge1'D and image2' A
        for i = 1 : (m/2)
            for j = 1: (n/2)
                % wavelet processing unit has 4*4 pixel
                wavelet_processing_unit1 = unit1(2*i-1 :2*i, 2*j-1:2*j);
                [a1,h1,v1,d1] = haart2(wavelet_processing_unit1,'integer');
                d_value1 = 1/3 * h1 + 1/3 * v1 + 1/3 * d1;
                vector1 = [vector1,d_value1];
                % fomula 16
                 wavelet_processing_unit2 = unit2(2*i-1 :2*i, 2*j-1:2*j);
                [a2,h2,v2,d2] = haart2(wavelet_processing_unit2,'integer');
                vector2 = [vector2,a2];
            end
        end
        A1_mean = mean(vector1);
        A2_mean = mean(vector2);
        s = size(unit1);
        sum = 0;
        for k = 1:s
            sum = sum+(vector1(k)-A1_mean)*(vector2(k)-A2_mean);
        end
        cov = sum/(m*n-1);
    end
end

end

