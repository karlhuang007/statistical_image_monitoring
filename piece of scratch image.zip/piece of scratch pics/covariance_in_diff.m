function [covariance] = covariance_in_diff(image1,image2,num1,num2)
%COVARIANCE_IN_DIFF �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% image1 and image2 have same size
[m,n] = size(image1);
% m and n must be even protect here
if mod(m,2)~=0
    m = m -1;
end

if mod(n,2)~=0
    n = n -1;
end
cov_vector= [];
%

    for i = 1 : (m/4)
        for j = 1: (n/4)
        % multivariate processing unit has 4*4 pixel
        multivariate_processing_unit1 = image1(4*(i-1)+1 :4*i, 4*(j-1)+1 :4*j);
        multivariate_processing_unit2 = image2(4*(i-1)+1 :4*i, 4*(j-1)+1 :4*j);
        cov = bi_wavelet_transform(multivariate_processing_unit1,multivariate_processing_unit2,num1,num2);
        cov_vector = [cov_vector,cov];
        end
    end

covariance = mean(cov_vector);
end

