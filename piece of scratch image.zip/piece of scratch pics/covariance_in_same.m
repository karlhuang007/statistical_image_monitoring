function [COV_AD] = covariance_in_same(single_frame_image)
%COVARIANCE_IN_SAME �˴���ʾ�йش˺�����ժҪ
%   
[m,n] = size(single_frame_image);
% m and n must be even protect here
if mod(m,2)~=0
    m = m -1;
end

if mod(n,2)~=0
    n = n -1;
end
S_AD_vector = [];

for i = 1 : (m/4)
    for j = 1: (n/4)
        % multivariate processing unit has 4*4 pixel
        multivariate_processing_unit = single_frame_image(4*(i-1)+1 :4*i, 4*(j-1)+1 :4*j);
        [A,D,S_A,S_D,COV_AD] = wavelet_transform(multivariate_processing_unit);
        S_AD_vector = [S_AD_vector,COV_AD];
    end
end
COV_AD = mean(S_AD_vector);
end

