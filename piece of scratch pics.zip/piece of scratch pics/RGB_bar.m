function [A_bar,D_bar] = RGB_bar(mono_pic)
%UNTITLED this function calculate the A_doublebar and D_doublebar of
%mono_pic
% para mono_pic is the R/G/B value of a color picture
%   �˴���ʾ��ϸ˵��


[m,n] = size(mono_pic);
% m and n must be even protect here
if mod(m,2)~=0
    m = m -1;
end

if mod(n,2)~=0
    n = n -1;
end
A_vector = [];
D_vector = [];
    
for i = 1 : (m/4)
    for j = 1: (n/4)
        % multivariate processing unit has 4*4 pixel
        multivariate_processing_unit = mono_pic(4*(i-1)+1 :4*i, 4*(j-1)+1 :4*j);
        [A,D] = wavelet_transform(multivariate_processing_unit);
        A_vector = [A_vector,A];
        D_vector = [D_vector,D];
    end
end
%fomular 18
A_bar = mean(A_vector);
D_bar = mean(D_vector);

end

