function [S_AP_square,S_DP_square] = RGB_variance(single_frame_image)
%RGB_VARIANCE this function calculate the variance of A:S_A_square and D:S_D_squar of
% single_frame_image

[m,n] = size(single_frame_image);
% m and n must be even protect here
if mod(m,2)~=0
    m = m -1;
end

if mod(n,2)~=0
    n = n -1;
end
S_A_vector = [];
S_D_vector = [];
for i = 1 : (m/4)
    for j = 1: (n/4)
        % multivariate processing unit has 4*4 pixel
        multivariate_processing_unit = mono_pic(4*(i-1)+1 :4*i, 4*(j-1)+1 :4*j);
        [A,D,S_A,S_D] = wavelet_transform(multivariate_processing_unit);
        S_A_vector = [S_A_vector,S_A];
        S_D_vector = [S_D_vector,S_D];
    end
end
S_AP_square = mean(S_A_vector);
S_DP_square = mean(S_D_vector);
end

