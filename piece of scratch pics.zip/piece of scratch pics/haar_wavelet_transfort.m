% im = rgb2gray(imread("image_part_003.png"));
im = rgb2gray(imread("good1.png"));
% b1 = imread("b1.png");
% 
% A = b1(5:6,5:6);
% [a,h,v,d] = haart2(A,'integer');
% a
% h
% v
% d

[m,n] = size(im);
% m and n must be even protect here
if mod(m,2)~=0
    m = m -1;
end

if mod(n,2)~=0
    n = n -1;
end
A_vector = [];
D_vector = [];
    
for i = 1 : (m/4)
    for j = 1: (n/4)
        % multivariate processing unit has 4*4 pixel
        multivariate_processing_unit = im(4*(i-1)+1 :4*i, 4*(j-1)+1 :4*j);
        [A,D] = wavelet_transform(multivariate_processing_unit);
        A_vector = [A_vector,A];
        D_vector = [D_vector,D];
    end
end
%fomular 18
A_bar = mean(A_vector);
D_bar = mean(D_vector);


