b1 = imread("b1.png");
r = b1(:,:,1);
g = b1(:,:,2);
b = b1(:,:,3);


%%

% first step calculate X_doublebar
[AR_bar,DR_bar] = RGB_bar(r);
[AG_bar,DG_bar] = RGB_bar(g);
[AB_bar,DB_bar] = RGB_bar(b);
X_doublebar = [AR_bar;DR_bar;AG_bar;DG_bar;AB_bar,DB_bar];

% calculate covariance function of a normal image

[S_AR_square,S_DR_square] = RGB_variance(r);
[S_AG_square,S_DG_square] = RGB_variance(g);
[S_AB_square,S_DB_square] = RGB_variance(b);

% calculate covariance function
n=6^2; % number of observation
for i = 1:n
    for j = 1:n
        % use ceil(i/25),ceil(j/25) to retrieve the row number of i,j in the checkerboard,
        % use mod(i,25),mod(j,25) to retrieve the column number of i,j in
        % the checkerboard. when mod(i,25) = 0, it mean the column is 25.
        % so the following situations should be considered.
        % Y = ceil( X ) rounds each element of X to the nearest integer greater than or equal to that element
        % b = mod( a , m ) returns the remainder after division of a by m
        if i == j
            
        
        end
        end
        end
        
        cov(i,j) = a * exp(b*E_norm);   % n*n dimention     
    end
end