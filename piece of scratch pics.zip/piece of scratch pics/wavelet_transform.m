function [A,D,A_SM_squar,D_SM_squar] = wavelet_transform(multivariate_processing_unit )
%WAVELET_TRANSFORM this function perform four wavelet transforms in input
%multivariate processing unit and return the A and D value of X_M_bar
%  PARA multivariate_processing_unit is 4*4 pixel in of R/G/B frame of
%  image

[m,n] = size(multivariate_processing_unit);
% m and n must be even protect here
if mod(m,2)~=0
    m = m -1;
end

if mod(n,2)~=0
    n = n -1;
end

A_vector = [];
D_vector = [];
    
for i = 1 : (m/2)
    for j = 1: (n/2)
        % wavelet processing unit has 4*4 pixel
        wavelet_processing_unit = multivariate_processing_unit(2*i-1 :2*i, 2*j-1:2*j);
        [a,h,v,d] = haart2(wavelet_processing_unit,'integer');
        A_vector = [A_vector,a];
        % fomula 16
        d_value = 1/3 * h + 1/3 * v + 1/3 * d;
        D_vector = [D_vector,d_value];
    end
end
% Formula 17
A = mean(A_vector);
D = mean(D_vector);
% formula 19
A_SM_squar = var(A_vector);
D_SM_squar = var(D_vector);
end

